module ApplicationHelper
	def resource_name
    :user
    end

def resource
    @resource ||= User.new
end

def resource_class 
    User 
end

def devise_mapping
    @devise_mapping ||= Devise.mappings[:user]
end

  def noticication_post_id(n)
      if n.event_type == "CommentLike"
        CommentLike.find(n.event_id).comment.post_id
      elsif n.event_type == "Comment"
        Comment.find(n.event_id).post_id
      elsif n.event_type == "Post"
        n.event_id
      elsif  n.event_type == "PostLike"
        PostLike.find(n.event_id).post_id
      end

  end

  def noticication_text(n)
    if n.event_type == "CommentLike"
      "Like Your Comment"
    elsif n.event_type == "Comment"
      "Comment on your post"
    elsif n.event_type == "Post"
      "tag post"
    elsif n.event_type == "PostLike"
      "Like Your Post"
    end

  end
end
