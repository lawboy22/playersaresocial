module PostsHelper
  def post_links_parser(word, post)
    if word.include?('youtube') || word.include?('youtu.be')
      # youtube = look_up_youtube(word)
      page = MetaInspector.new(word)
      post.update_attributes(post_link: word, is_post_link_data: true, post_type: "Youtube", link_title: page.title, link_description: page.description, link_preview_pic: open(page.images.best, 'User-Agent' => 'Ruby'))
      # post.update_attributes(link_description: youtube[0].html_safe, post_type: "Youtube", is_post_link_data: true) if youtube[0].present?
    else
      unless word.include?(" ")
        page = MetaInspector.new(word)
        web_data = set_scape_web_data(page)
        if web_data["pic"].present? || web_data["title"].present? || web_data["desc"].present?
          web_photo_data = web_data["pic"].present? ?
              (begin
                open(web_data["pic"], 'User-Agent' => 'Ruby')
              rescue
                ''
              end) : nil
          link_image = nil
          if web_photo_data.present? && web_photo_data.class == Tempfile
            link_image = web_photo_data
          elsif web_photo_data.class == StringIO
            web_temp_file = Tempfile.new
            IO.copy_stream(web_photo_data, web_temp_file)
            link_image = web_temp_file
          end
          post.update_attributes(post_link: word, is_post_link_data: true, post_type: "Web", link_preview_pic: link_image, link_title: web_data["title"], link_description: web_data["desc"])
        else
          post.update_attributes(post_link: word, is_post_link_data: true, post_type: "Web", link_title: page.title, link_description: page.description)
          # post.update_attributes(post_link: word, is_post_link_data: false)
        end
      end
    end
  end

  def set_scape_web_data(page)
    begin
      hash_data = {"pic" => '', "title" => '', "desc" => ''}
      if page.meta_tags["property"].present?
        if page.meta_tags["property"]["og:image"].instance_of? Array
          hash_data["pic"] = page.meta_tags["property"]["og:image"][0].to_s.start_with?("http") ? page.meta_tags["property"]["og:image"][0] : (page.meta_tags["property"]["og:url"][0].to_s + page.meta_tags["property"]["og:image"][0].to_s).split("/").reject{|p| p.blank?}.join("/")
          hash_data["title"] = page.meta_tags["property"]["og:title"][0] if page.meta_tags["property"]["og:title"].present?
          hash_data["desc"] = page.meta_tags["property"]["og:description"].present? ? page.meta_tags["property"]["og:description"][0] : page.meta_tags["name"]["description"][0]
        else
          hash_data["pic"] = page.meta_tags["property"]["og:image"].start_with?("http") ? page.meta_tags["property"]["og:image"] : (page.meta_tags["property"]["og:url"] + page.meta_tags["property"]["og:image"]).split("/").reject{|p| p.blank?}.join("/")
          hash_data["title"] = page.meta_tags["property"]["og:title"]
          hash_data["desc"] = page.meta_tags["property"]["og:description"].present? ? page.meta_tags["property"]["og:description"] : page.meta_tags["name"]["description"]
        end
      end
    return hash_data
    rescue
      return hash_data
    end
  end

  def post_description(post)
    post.description.split(" ").each do |word|
      post_links_parser(word, post) if word.start_with?("http")
    end
  end

  def look_up_youtube(str)
    found = Array.new
    splitted = str.split(" ");
    splitted.each do |s|
      now = s
      if( now["https://www.youtube.com/watch?"] || now["https://m.youtube.com/watch?"] || now["https://youtu.be/watch?"] )
        source = embed(now)
        found.push(%Q[ <iframe width="84%" height="480" class="youtube" src="#{source}?wmode=transparent" frameborder="0" allowfullscreen> </iframe> ])
        found.push(now)
        break
      end
    end
    # If a Sound Cloud link was found, it will return the new string.
    return found
  end

  def embed(youtube_url)
    youtube_id = youtube_url.split("=").last
    return "https://www.youtube.com/embed/#{youtube_id}"
  end

end
