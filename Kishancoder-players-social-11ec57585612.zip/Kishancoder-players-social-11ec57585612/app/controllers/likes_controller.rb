class LikesController < ApplicationController
  before_action :find_comment

  def create
    if @comment.present?
      clike=current_user.comment_likes.create(like_user_id: params[:user_id], comment_id: params[:id])
      Notification.notify(clike.comment.user_id,current_user.id,clike.class.name,clike.id)
    end
    respond_to do |format|
      format.js
    end
  end

  def destroy
    if @comment.present?
      current_user.comment_likes.where(comment_id: params[:id]).destroy_all
    end
    respond_to do |format|
      format.js
    end
  end

  private
  def find_comment
    @comment = Comment.where(id: params[:id]).first
  end
end