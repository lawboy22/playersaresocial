class RegistrationsController < Devise::RegistrationsController
  before_action :configure_permitted_parameters
  prepend_before_action :authenticate_scope!, only: [:edit, :update, :destroy, :change_password, :changed_password]
  # skip_before_action :authenticate_user!, only: [:new, :create]

  def changed_password
    self.resource = current_user
    if resource.update_with_password(account_update_params)
      bypass_sign_in(resource)
      redirect_to root_path
    else
      render 'change_password'
    end
  end

  def update
    if resource.update_without_password(account_update_params)
      flash[:notice] = "profile updated successfully."
      redirect_to root_path
    else
      render 'edit'
    end
  end

  private

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up) do |user_params|
      user_params.permit(:email, :password, :password_confirmation, :name, :image, :user_id)
    end
    devise_parameter_sanitizer.permit(:account_update) do |user_params|
      user_params.permit(:current_password, :password, :password_confirmation, :name, :image)
    end
  end

  def after_update_path_for(resource)
    root_path
  end
end
