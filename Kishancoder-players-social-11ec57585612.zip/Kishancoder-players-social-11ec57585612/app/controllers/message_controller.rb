class MessageController < ApplicationController
  def index
  end

  def create
  end

  def show
  end

  def new
  end
end
