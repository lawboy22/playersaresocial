class HomeController < ApplicationController
  before_action :authenticate_user!, :only => [:add_roaster,:add_follow]
  
  def index
  end

  def user
    @user = User.find(params["id"])
  end

  def users
  	@users = User.where.not(id: current_user.id)
  end

  def my_posts
  end

  def notifications
    @tags = TagUser.where('tag_id =? and tag_type =?',"#{current_user.id}","User").order('created_at desc')
    @user_notification = Notification.where("user_to_notify = ? and user_who_fired_event not in (?)", current_user.id, current_user.id).order("created_at DESC")
    if @user_notification.present?
      unread_notic = @user_notification.where(is_read: false)
      unread_notic.update_all(is_read: true) if unread_notic.present?
    end
  end

  def add_roaster
  	player = Player.find(params["id"])
  	current_user.follow(player)

    respond_to do |format|
      format.html { redirect_back(fallback_location: players_path); flash[:notice] = 'Player added to Roster list' }
    end
  end

  def add_follow
  	player = User.find(params["id"])
  	current_user.follow(player)
    
    respond_to do |format|
      format.html { redirect_to users_path, notice: 'User added to followings list' }
    end
  end

  def remove_roaster
    player = Player.find(params["id"])
    current_user.stop_following(player)

    respond_to do |format|
      format.html { redirect_back(fallback_location: players_path); flash[:notice] =  'Player removed from Roster list' }
    end
  end

  def remove_follow
    user = User.find(params["id"])
    current_user.stop_following(user)

    respond_to do |format|
      format.html { redirect_to users_path, notice: 'User removed from followings list' }
    end
  end

  def policy
  end

  def terms
  end

  def search
    @query = params["query"]
    if @query.start_with?("@") || @query.start_with?("#")
      @query.slice!(0)
    end
    if @query.present?
      @users = User.where('lower(name) LIKE (?) or lower(users.user_id) LIKE (?)',"%#{@query.downcase}%", "%#{@query.downcase}%")
      @players = Player.where('lower(name) LIKE (?)',"%#{@query.downcase}%")
      @tags = Tag.where('lower(title) LIKE (?)',"%#{@query.downcase}%")
      # @posts = Post.joins(:tags).where("lower(tags.title) LIKE (?)","%#{@query.downcase}%")
      @posts = Post.joins("LEFT JOIN tags ON tags.post_id = posts.id").joins("LEFT JOIN comments ON comments.post_id = posts.id LEFT JOIN comment_tags ON comment_tags.comment_id = comments.id").where("lower(tags.title) LIKE (?) OR lower(comment_tags.title) LIKE (?)","%#{@query.downcase}%","%#{@query.downcase}%").order("posts.created_at DESC")
    end
  end
end
