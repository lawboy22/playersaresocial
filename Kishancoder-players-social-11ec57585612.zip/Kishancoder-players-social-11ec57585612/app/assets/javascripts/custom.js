$(document).on('turbolinks:load', function() {
    $(document).on('click','.post_comment',function(e) {
      id = $(this).attr('id');
      $("#comments_"+id).show();
    });
    function readURL(input, upload_div_obj) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                var img = new Image();
                img.src = e.target.result;
                img.className='media-object-profile'
                upload_div_obj.find('.target').html(img);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    $(".upload_image").change(function(){
        readURL(this, $(this).closest('.upload_image_preview'));
    })
    $('.rightSidebar').theiaStickySidebar({
            'additionalMarginTop': 150,
            'sidebarBehavior': 'modern',
    }
    );
    $('.trending').liMarquee({});

    // $('.trending').slick({
    //     slidesToShow: 6,
    //     dots:false,
    //     arrows:false,
    //     autoplay:true,
    //     autoplaySpeed: 2000,
    //     responsive:[{
    //         breakpoint:1441,
    //         settings:{slidesToShow:8}},
    //         {breakpoint:1025,settings:{centerPadding:'10px',slidesToShow:4,}},
    //         {breakpoint:767,settings:{centerPadding:'10px',slidesToShow:1}}]});

    $(".img-input").change(function () {
        readPostURL(this);
    });
    $(document).on('click',".mob-roster-menu",function () {
        $("#navbarTogglerDemo02").collapse('hide');
        $(".mob-tab, .mob-roster-close, #show-search-mob").removeClass('d-none')
        $(".mob-roster-menu, #show-search-mob-close").addClass('d-none')
        $(".mob-header-search").removeClass('open');
        $('body').addClass('body-fix');
    });
    $(document).on('click',".mob-roster-close",function () {
        $(".mob-tab, .mob-roster-close, #show-search-mob-close").addClass('d-none');
        $(".mob-roster-menu, #show-search-mob").removeClass('d-none');
        $(".mob-header-search").removeClass('open');
        $('body').removeClass('body-fix');
    });
    $(document).on('click',"#show-search-mob",function () {
        $("#navbarTogglerDemo02").collapse('hide');
        $(".mob-header-search").addClass('open');
        $(".mob-tab, .mob-roster-close, #show-search-mob").addClass('d-none')
        $(".mob-roster-menu, #show-search-mob-close, .mob-header-search").removeClass('d-none')
        $('body').removeClass('body-fix');
    });
    $(document).on('click',"#show-search-mob-close",function () {
        $(".mob-header-search").removeClass('open');
        $(".mob-tab, .mob-roster-close, #show-search-mob-close, .mob-header-search").addClass('d-none');
        $(".mob-roster-menu, #show-search-mob").removeClass('d-none');
    });
    $(document).on('click',"#show-menu-mob",function () {
        $(".mob-header-search").removeClass('open');
        $('body').removeClass('body-fix');
        $(".mob-tab, .mob-roster-close, #show-search-mob-close, .mob-header-search").addClass('d-none');
        $(".mob-roster-menu, #show-search-mob").removeClass('d-none');
    });

    $(".search-query").keyup(function () {
        if($(this).val() == ""){
            $(".search-suggestion-player, .search-suggestion-user, .all-result, .search-suggestion-tags").empty();
        }else{
            $(this).closest('.search-form').trigger('submit.rails')
        }
    })

    $(window).scroll(function(){
        var scroll = $(window).scrollTop();
        if (scroll <= 1) {
            $('header').removeClass('sticky');
        }
        else {
            $('header').addClass('sticky');
        }
    });

  })

function readPostURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.img-input-tag').attr('src', e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}