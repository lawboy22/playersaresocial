class ApplicationMailer < ActionMailer::Base
  default from: 'no-reply@fantasychirps.com'
  layout 'mailer'
end
