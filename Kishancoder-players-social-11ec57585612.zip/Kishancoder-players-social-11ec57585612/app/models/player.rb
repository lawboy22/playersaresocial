class Player < ApplicationRecord
	acts_as_followable
	has_attached_file :image,:storage => :cloudinary, styles: { small: "64x64", med: "100x100", profile: "140x140" }, :path => ":env_folder/:attachment/:id/:style/:filename"
	validates_attachment_content_type :image, 
                                    :content_type => /^image\/(png|gif|jpeg|jpg)/,
                                    :message => 'only (png/gif/jpeg/jpg) images'
    has_many :posts
    validate :uniqee_user_id, on: :create
    validates :username, uniqueness: { message: "User Name should be uniqee" }, :case_sensitive => false
    after_create :update_username

    def uniqee_user_id
	    user_id = self.username
	    players = Player.where('lower(username) =?', username.downcase)
			users = User.where('lower(user_id) =?', username.downcase)
	    if players.count > 0 || users.count > 0
				errors.add(:base, "Username has already been taken.")
	    end
	  end

	  def update_username
	  	self.update_attributes(:username=>self.username.downcase)
	  end

end
