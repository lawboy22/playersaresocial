class CommentTagUser < ApplicationRecord
  belongs_to :comment
end
