class Conversation < ApplicationRecord
end
