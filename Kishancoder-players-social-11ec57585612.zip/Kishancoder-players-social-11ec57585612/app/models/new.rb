class New < ApplicationRecord
end
