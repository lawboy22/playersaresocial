class Tag < ApplicationRecord
  belongs_to :post
end
