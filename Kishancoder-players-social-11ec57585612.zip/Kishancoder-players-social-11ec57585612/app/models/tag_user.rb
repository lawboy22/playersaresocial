class TagUser < ApplicationRecord
	belongs_to :post
end
