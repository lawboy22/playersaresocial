class Comment < ApplicationRecord
  belongs_to :user
  belongs_to :post
  has_many :comment_likes, :dependent => :destroy
  has_many :comment_reports,:dependent => :destroy

  has_many :comment_tags,:dependent => :destroy
  has_many :comment_tag_users,:dependent => :destroy
end
