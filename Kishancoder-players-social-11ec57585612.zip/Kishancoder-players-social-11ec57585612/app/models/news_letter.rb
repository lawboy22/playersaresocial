class NewsLetter < ApplicationRecord
end
