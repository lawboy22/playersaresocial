class Notification < ApplicationRecord
  belongs_to :from_user, foreign_key: 'user_who_fired_event', class_name: 'User'
  belongs_to :to_user, foreign_key: 'user_to_notify', class_name: 'User'

  def self.notify(other_user, user, event, eid)
    Notification.create(user_to_notify: other_user, user_who_fired_event: user, event_type: event, event_id: eid)
  end
end