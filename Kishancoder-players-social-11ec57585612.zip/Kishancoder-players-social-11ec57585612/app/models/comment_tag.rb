class CommentTag < ApplicationRecord
  belongs_to :comment
end
