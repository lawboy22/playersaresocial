Gibbon::Request.api_key = "074125d12e20b39ac706aaec124b08bf-us19"
Gibbon::Request.timeout = 15
Gibbon::Request.throws_exceptions = true
puts "MailChimp API key: #{Gibbon::Request.api_key}" # temporary

