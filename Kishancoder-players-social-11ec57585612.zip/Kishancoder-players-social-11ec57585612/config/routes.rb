Rails.application.routes.draw do
  get 'message/index'

  get 'message/create'

  get 'message/show'

  get 'message/new'

  root 'home#index'
  get 'user/:id' => 'home#user',as: :user
  get 'users' => 'home#users',as: :users
  get 'add_roaster/:id' => 'home#add_roaster', as: :add_roaster
  get 'add_follow/:id' => 'home#add_follow', as: :add_follow
  get 'remove_follow/:id' => 'home#remove_follow', as: :remove_follow
  get 'remove_roaster/:id' => 'home#remove_roaster', as: :remove_roaster
  get 'my_posts' => 'home#my_posts', as: :my_posts
  get 'search' => 'home#search',as: :search
  get 'notifications' => 'home#notifications',as: :notifications

  devise_for :admin_users, ActiveAdmin::Devise.config
  ActiveAdmin.routes(self)
  devise_for :users, controllers: {
      registrations: "registrations"
  }
  devise_scope :user do
    get    '/users/registrations/change_password',  to: 'registrations#change_password',  as: :change_password
    put    '/users/registrations/:id/changed_password',  to: 'registrations#changed_password',  as: :changed_password
  end

  resources :players
  resources :posts do
    get :find_post_comments, on: :collection
    get :unlike, on: :member
    get :like, on: :member
    get :report, on: :member
  end
  resources :comments do
    get :report, on: :member
  end
  resources :likes

  get 'privacy-policy' => 'home#policy'
  get 'terms' => 'home#terms'


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
