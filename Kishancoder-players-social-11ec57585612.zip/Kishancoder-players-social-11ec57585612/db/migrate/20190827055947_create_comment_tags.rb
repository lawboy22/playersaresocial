class CreateCommentTags < ActiveRecord::Migration[5.1]
  def change
    create_table :comment_tags do |t|
      t.references :comment, foreign_key: true
      t.string :title

      t.timestamps
    end
  end
end
