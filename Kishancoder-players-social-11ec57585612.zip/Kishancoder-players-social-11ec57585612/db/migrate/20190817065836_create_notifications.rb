class CreateNotifications < ActiveRecord::Migration[5.1]
  def change
    create_table :notifications do |t|
      t.integer :user_to_notify
      t.integer :user_who_fired_event
      t.string :event_type
      t.integer :event_id
      t.boolean :is_read, default: false
      t.timestamps
    end
  end
end