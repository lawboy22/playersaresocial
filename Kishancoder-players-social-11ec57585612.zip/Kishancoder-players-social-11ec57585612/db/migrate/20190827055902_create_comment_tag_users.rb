class CreateCommentTagUsers < ActiveRecord::Migration[5.1]
  def change
    create_table :comment_tag_users do |t|
      t.string :tag_id
      t.string :tag_type
      t.references :comment, foreign_key: true

      t.timestamps
    end
  end
end
