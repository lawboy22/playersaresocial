class AddLinkDataIPostTable < ActiveRecord::Migration[5.1]
  def change
    add_column :posts, :post_type, :string
    add_attachment :posts, :link_preview_pic
    add_column :posts, :link_title, :string
    add_column :posts, :link_description, :string
    add_column :posts, :post_link, :string
    add_column :posts, :is_post_link_data, :boolean, default: false
  end
end