require 'test_helper'

class NewsLetterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
