require 'test_helper'

class TagUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
