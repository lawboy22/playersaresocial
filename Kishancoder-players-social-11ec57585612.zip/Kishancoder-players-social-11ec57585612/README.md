# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version
2.3.1

* System dependencies
Ruby 2.3.1 <br>
Rails 5.1 <br>
Postgresql ((for database) <br>
Node.js (for assets) <br>
git

* Configuration
git clone <br>
rvm use 2.3.1 <br>

* Database creation
rake db:create

* Database initialization
rake db:migrate

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions
set git remote <br>
git push heroku master
* ...
